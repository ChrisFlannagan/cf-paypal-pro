=== PayPal Pro for Caldera Forms ===
Contributors:      MrFlannagan
Tags:              calderawp, caldera forms, wpform, form, responsive, paypal, pro, payment processor
Requires at least: 4.5
Tested up to:      4.9.1
Stable Tag: 1.0.2
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

