<?php

\CF_PayPal_Pro\Util\Config::render_ui();