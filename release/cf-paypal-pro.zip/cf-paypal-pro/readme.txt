=== PayPal Pro for Caldera Forms ===
Contributors:      MrFlannagan
Tags:              calderawp, caldera forms, wpform, form, responsive, paypal, pro, payment processor
Requires at least: 4.0
Tested up to:      4.8.2
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

